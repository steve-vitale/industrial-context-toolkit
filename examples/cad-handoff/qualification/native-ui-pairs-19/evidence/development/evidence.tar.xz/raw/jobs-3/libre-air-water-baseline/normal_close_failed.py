import json,time,subprocess
from pathlib import Path
root=Path('/work');(root/'request.json').write_text(json.dumps(dict(seq=900,action='status')))
p=root/'replies/900.json'
for i in range(100):
 if p.exists():break
 time.sleep(.2)
assert p.exists()
obs=json.loads(p.read_bytes());assert obs['filename']=='' and obs['modified'] is False
r=subprocess.run(['wmctrl','-l'],capture_output=True,text=True);rows=[x for x in r.stdout.splitlines() if x.endswith('Untitled 1 - QCAD Professional Trial')];assert len(rows)==1
cmd=['wmctrl','-ic',rows[0].split()[0]];closed=subprocess.run(cmd,capture_output=True,text=True)
(root/'normal-close-failed.json').write_text(json.dumps(dict(observation=obs,windows=r.stdout,command=cmd,exit=closed.returncode,stdout=closed.stdout,stderr=closed.stderr)))
assert closed.returncode==0
