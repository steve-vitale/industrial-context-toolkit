import hashlib,json,os,subprocess
from pathlib import Path
root=Path.cwd();q=root/'examples/cad-handoff/qualification';out=root/'data/external/cad-qualification/font-probe-4';out.mkdir()
exe=Path(r'C:\Users\Steve\.cp-scratch\qcad-3.33.1-qt5-native-test\application\qcad-3.33.1-trial-win64\qcadcmd.com')
manifest=root/'data/external/cad-qualification/render-diagnostic-3/bounds-manifest.json'
cmd=[str(exe),'-platform','offscreen','-no-gui','-allow-multiple-instances','-config',str(out/'probe-settings'),'-autostart',str(q/'native-view-bounds.js'),'-m',str(manifest)]
p=subprocess.run(cmd,cwd=exe.parent,env=dict(os.environ,QT_QPA_FONTDIR=r'C:\Windows\Fonts'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
(out/'probe.log').write_bytes(p.stdout)
rows=[json.loads(l.split('ICT_VIEW_BOUNDS ',1)[1]) for l in p.stdout.decode('utf-8',errors='replace').splitlines() if l.startswith('ICT_VIEW_BOUNDS ')]
r=dict(command=cmd,exit=p.returncode,helper_sha256=hashlib.sha256((q/'native-view-bounds.js').read_bytes()).hexdigest(),rows=rows)
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
assert p.returncode==0 and len(rows)==12 and not any(row.get('error') for row in rows)
print(json.dumps({row['id']:sorted({(e['font'],e['font_file']) for route in ('source','candidate') for e in row[route] if 'font' in e}) for row in rows},indent=2))
