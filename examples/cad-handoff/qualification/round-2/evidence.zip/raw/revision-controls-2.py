"""Execute fictional source-revision/concurrent-branch and draft-context controls."""
import copy
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd()
OUT = ROOT / 'data/external/cad-qualification/revision-controls-2'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT / 'scripts'))
import cad_handoff as ch
import cad_value_patch as patcher
sys.path.insert(0, str(ROOT / 'examples/cad-handoff/qualification'))
from verify_bytes import verify

source = ROOT / 'examples/cad-handoff/source/valve.dxf'
plan = json.loads((source.parent / 'edit-plan.json').read_bytes())
raw = source.read_bytes()
patcher.apply(source, plan, OUT / 'proposal-1')
first = OUT / 'proposal-1/candidate.dxf'
checks = dict(fictional_simulation=True, human_manual_edit=False, original_sha256=ch.digest(source))
refusals = {}
for name, current, proposal in [
    ('stale-source-hash', first, plan),
    ('fresh-hash-wrong-before', first, dict(plan, source_sha256=ch.digest(first))),
]:
    destination = OUT / name
    try:
        patcher.apply(current, proposal, destination)
    except ch.InputError as error:
        refusals[name] = str(error)
    else:
        raise AssertionError('Stale proposal admitted: ' + name)
    assert not destination.exists()

# Authored concurrent branch: all same proposed changes except a conflicting MODEL.
manual = copy.deepcopy(plan)
for change in manual['changes']:
    if change['attribute'] == 'MODEL':
        change['after'] = 'MANUAL-OTHER'
        change['reason'] = 'Fictional concurrent manual branch; authored control, not a human edit'
patcher.apply(source, manual, OUT / 'concurrent-branch')
returned = OUT / 'concurrent-branch/candidate.dxf'
review = ch.review(source, returned, plan, OUT / 'conflict-review')
assert review['strict_difference_count'] == 1
conflicts = [row for row in review['asset_attributes'] if row['status'] == 'planned edit missing or different']
assert len(conflicts) == 1 and conflicts[0]['attribute'] == 'MODEL'
assert conflicts[0]['after'] == 'MANUAL-OTHER' and conflicts[0]['planned_after'] == 'SRC-3'
checks['explicit_conflicts'] = conflicts

# New proposal binds the chosen current source and before value; no automatic merge.
resolved = dict(schema='cad-edit-plan-1', source_sha256=ch.digest(returned), changes=[
    dict(id=plan['changes'][0]['id'], attribute='MODEL', before='MANUAL-OTHER', after='SRC-4',
         reason='Authored reconciliation control; real engineering approval is not represented')])
ch.write_json(OUT / 'revision-2-plan.json', resolved)
patcher.apply(returned, resolved, OUT / 'revision-2')
checks['revision_2_bytes'] = verify(returned, OUT / 'revision-2/candidate.dxf', resolved)

path = ROOT / 'examples/cad-handoff/project_to_map.py'
spec = importlib.util.spec_from_file_location('cad_context_projection', path)
projection = importlib.util.module_from_spec(spec)
spec.loader.exec_module(projection)
mapping = json.loads((source.parent / 'site-mapping.json').read_bytes())
projection.project(OUT / 'proposal-1', mapping, OUT / 'map-before')
projection.project(OUT / 'revision-2/candidate-context', mapping, OUT / 'map-selected')
commands = []
for label in ('map-before', 'map-selected'):
    command = [sys.executable, 'scripts/one_map.py', 'build', str(OUT / label / 'site.json'), '--out', str(OUT / label / 'map')]
    proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT / (label + '.log')).write_bytes(proc.stdout)
    commands.append(dict(command=command, exit=proc.returncode))
    assert proc.returncode == 0
command = [sys.executable, 'scripts/one_map.py', 'changes', str(OUT / 'map-before/map/graph.json'),
           str(OUT / 'map-selected/map/graph.json'), '--out', str(OUT / 'map-change')]
proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(OUT / 'map-change.log').write_bytes(proc.stdout)
commands.append(dict(command=command, exit=proc.returncode))
assert proc.returncode == 0
selected = json.loads((OUT / 'map-selected/sheet.json').read_bytes())['instruments'][0]['attributes']
assert selected['cad_model'] == 'SRC-4' and selected['cad_size'] == 'DN65'
assert all(k.startswith('cad_') for k in selected)
assert (OUT / 'map-before/cad-source.dxf').read_bytes() == raw
assert (OUT / 'map-selected/cad-source.dxf').read_bytes() == (OUT / 'revision-2/candidate.dxf').read_bytes()
assert source.read_bytes() == raw
checks.update(refusals=refusals, selected_context=selected, commands=commands,
              retained_original_unchanged=True,
              scope='Fictional local branch/revision and explicitly mapped draft CAD-reference projection. No installed register, authenticated decision or company system is connected.')
ch.write_json(OUT / 'checks.json', checks)
print(json.dumps(checks, indent=2))
