"""Orchestrate the frozen native helper; retain all selected outputs and readbacks."""
import hashlib
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path

ROOT = Path.cwd()
Q = ROOT / 'examples/cad-handoff/qualification'
OUT = ROOT / 'data/external/cad-qualification/native-validation-2'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT / 'scripts'))
import cad_handoff as ch

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
text_sha = lambda p: hashlib.sha256(Path(p).read_bytes().replace(b'\r\n', b'\n')).hexdigest()
freeze = Q / 'METHOD-FREEZE-2.json'
for path, wanted in json.loads(freeze.read_bytes())['methods'].items():
    assert text_sha(ROOT / path) == wanted, path
helper = Q / 'native-batch.js'
exe = Path(r'C:\Users\Steve\.cp-scratch\qcad-3.33.1-qt5-native-test\application\qcad-3.33.1-trial-win64\qcadcmd.com')
cases = []
for manifest, results in [(Q / 'validation-2/authored/MANIFEST.json', ROOT / 'data/external/cad-qualification/validation-2-authored'),
                          (Q / 'validation-2/public-adapted/MANIFEST.json', ROOT / 'data/external/cad-qualification/validation-2-public')]:
    for c in json.loads(manifest.read_bytes())['cases']:
        identity = c['id']
        cases.append(dict(id=identity, source=str(manifest.parent / c['source']),
                          plan=str(manifest.parent / c['plan']), candidate=str(results / identity / 'candidate/candidate.dxf'),
                          native_default=str(OUT / (identity + '-default.dxf')),
                          native_r15=str(OUT / (identity + '-r15.dxf'))))
assert len(cases) == 12

def native(manifest, label):
    path = OUT / (label + '-manifest.json')
    path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    command = [str(exe), '-platform', 'offscreen', '-no-gui', '-allow-multiple-instances',
               '-config', str(OUT / (label + '-settings')), '-autostart', str(helper), '-m', str(path)]
    proc = subprocess.run(command, cwd=exe.parent, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          timeout=120, creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / (label + '-log.txt')).write_bytes(proc.stdout)
    log = proc.stdout.decode('utf-8', errors='replace')
    readbacks = [json.loads(line.split('ICT_QUAL_NATIVE ', 1)[1]) for line in log.splitlines()
                 if line.startswith('ICT_QUAL_NATIVE ')]
    receipt = dict(command=command, process_exit=proc.returncode, helper_sha256=sha(helper),
                   executable_sha256=sha(exe), driver_sha256=sha(Path(__file__)),
                   freeze_sha256_lf=text_sha(freeze), expected=len(manifest['cases']), returned=len(readbacks),
                   input_hashes={c['id']: {k: sha(c[k]) for k in ('source', 'plan', 'candidate')} for c in manifest['cases']},
                   readbacks=readbacks, scope='native engine API only; no GUI or engineering acceptance')
    (OUT / (label + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    assert proc.returncode == 0 and len(readbacks) == len(manifest['cases']) and 'ICT_QUAL_FATAL' not in log
    return readbacks

def grouped(rows):
    known, other = {}, Counter()
    for row in rows:
        values = row['attributes']
        identity = values.get('ICT_ID')
        if identity:
            if identity in known:
                raise ValueError('Duplicate native identity: ' + identity)
            known[identity] = values
        else:
            other[json.dumps(values, sort_keys=True)] += 1
    return known, other

expected, before = {}, {}
for c in cases:
    snap = ch.snapshot(Path(c['source']))
    before[c['id']] = {a['id']: a['attributes'] for a in snap['assets']}
    expected[c['id']] = json.loads(json.dumps(before[c['id']]))
    for change in json.loads(Path(c['plan']).read_bytes())['changes']:
        assert expected[c['id']][change['id']][change['attribute']] == change['before']
        expected[c['id']][change['id']][change['attribute']] = change['after']

readbacks = native(dict(cases=cases), 'edited')
summary = []
for c, r in zip(cases, readbacks):
    assert c['id'] == r['id']
    item = dict(id=c['id'], errors={k: v for k, v in r.items() if k.endswith('error')}, routes={})
    try:
        source_rows, foreign = grouped(r['source'])
        item['source_stored_attributes_match'] = source_rows == before[c['id']]
        plan = json.loads(Path(c['plan']).read_bytes())
        for route in ('candidate', 'native_default', 'native_r15'):
            if route not in r:
                item['routes'][route] = dict(error='No native readback returned')
                continue
            actual, extra = grouped(r[route])
            comparison = ch.compare(ch.snapshot(Path(c['source'])), ch.snapshot(Path(c[route])), plan)
            item['routes'][route] = dict(all_profiled_stored_attributes_match=actual == expected[c['id']],
                                        unprofiled_attribute_groups_preserved=extra == foreign,
                                        strict_status=comparison['status'], strict_differences=len(comparison['unexpected']),
                                        sha256=sha(c[route]))
            (OUT / (c['id'] + '-' + route + '-comparison.json')).write_text(json.dumps(comparison, indent=2) + '\n', encoding='utf-8')
    except Exception as error:
        item['error'] = f'{type(error).__name__}: {error}'
    summary.append(item)
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2), flush=True)

# Closed first process, then reopen every candidate and every available returned file.
fresh_cases, owners = [], []
for c in cases:
    for route in ('candidate', 'native_default', 'native_r15'):
        if Path(c[route]).is_file():
            fresh_cases.append(dict(id=c['id'] + ':' + route, source=c['source'], plan=c['plan'], candidate=c[route]))
            owners.append((c['id'], route))
fresh = native(dict(read_only=True, cases=fresh_cases), 'fresh-process')
checks = []
for (identity, route), r in zip(owners, fresh):
    check = dict(id=identity, route=route, error=r.get('error'))
    try:
        original, foreign = grouped(r['source'])
        actual, extra = grouped(r['candidate'])
        check.update(source_stored_attributes_match=original == before[identity],
                     all_profiled_stored_attributes_match=actual == expected[identity],
                     unprofiled_attribute_groups_preserved=extra == foreign)
    except Exception as error:
        check['error'] = f'{type(error).__name__}: {error}'
    checks.append(check)
(OUT / 'fresh-process-checks.json').write_text(json.dumps(checks, indent=2) + '\n', encoding='utf-8')
good = all(not c['error'] and c.get('source_stored_attributes_match') and c.get('all_profiled_stored_attributes_match')
           and c.get('unprofiled_attribute_groups_preserved') for c in checks)
print('Fresh process:', len(checks), 'route readbacks; all attribute checks:', good)
raise SystemExit(0 if good and len(checks) == 36 else 1)
