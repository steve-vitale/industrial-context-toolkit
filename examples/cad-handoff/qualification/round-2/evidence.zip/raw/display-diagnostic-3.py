import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
OUT = ROOT / 'data/external/cad-qualification/render-diagnostic-3'
OUT.mkdir()
Q = ROOT / 'examples/cad-handoff/qualification'
EXE = Path(r'C:\Users\Steve\.cp-scratch\qcad-3.33.1-qt5-native-test\application\qcad-3.33.1-trial-win64\qcadcmd.com')
FONT = Path(r'C:\Windows\Fonts\arial.ttf')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
cases = json.loads((ROOT / 'data/external/cad-qualification/native-validation-2/edited-manifest.json').read_bytes())['cases']
manifest = OUT / 'bounds-manifest.json'
manifest.write_text(json.dumps(dict(cases=cases), indent=2) + '\n', encoding='utf-8')
env = dict(os.environ, QT_QPA_FONTDIR=str(FONT.parent))
command = [str(EXE), '-platform', 'offscreen', '-no-gui', '-allow-multiple-instances',
           '-config', str(OUT / 'bounds-settings'), '-autostart', str(Q / 'native-view-bounds.js'), '-m', str(manifest)]
proc = subprocess.run(command, cwd=EXE.parent, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                      timeout=120, creationflags=subprocess.CREATE_NO_WINDOW)
(OUT / 'bounds.log').write_bytes(proc.stdout)
rows = [json.loads(l.split('ICT_VIEW_BOUNDS ', 1)[1]) for l in proc.stdout.decode('utf-8', errors='replace').splitlines()
        if l.startswith('ICT_VIEW_BOUNDS ')]
receipt = dict(command=command, exit=proc.returncode, rows=rows, helper_sha256=sha(Q / 'native-view-bounds.js'),
               executable_sha256=sha(EXE), font_sha256=sha(FONT), process_environment=dict(QT_QPA_FONTDIR=str(FONT.parent)),
               driver_sha256=sha(__file__))
(OUT / 'bounds-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
assert proc.returncode == 0 and len(rows) == 12 and not any(r.get('error') for r in rows)
case = next(c for c in cases if c['id'] == 'validation-cp1251')
data = next(r for r in rows if r['id'] == case['id'])
assert not any(e.get('bounds_error') for route in ('source', 'candidate') for e in data[route] if e.get('tag'))
blocks = sorted({e['block'] for r in rows for e in r['source']})
print('Observed native blocks:', json.dumps(blocks), flush=True)

def groups(records):
    parents = {r['parent']: r['text'] for r in records if r.get('tag') == 'ICT_ID'}
    return {identity: [r for r in records if r.get('parent') == parent] for parent, identity in parents.items()}

identity = sorted(groups(data['source']))[0]
entities = [e for route in ('source', 'candidate') for e in groups(data[route])[identity]]
xs = [v for e in entities for v in (e['bounds'][0], e['bounds'][2])]
ys = [v for e in entities for v in (e['bounds'][1], e['bounds'][3])]
pad = max(max(xs) - min(xs), max(ys) - min(ys), 1) * .5
window = ','.join(f'{v:.8f}' for v in (min(xs)-pad, min(ys)-pad, max(xs)-min(xs)+2*pad, max(ys)-min(ys)+2*pad))
jobs = [dict(route=route, font=font, input=case[route], window=window, width=3200, height=2200)
        for font in ('original', 'Arial-substitution') for route in ('source', 'candidate')]
(OUT / 'pilot-plan.json').write_text(json.dumps(dict(id=case['id'], identity=identity, jobs=jobs,
    scope='Display-only diagnostic; native bounds and common windows. Monochrome, trial watermark retained. '
          'Arial substitution is not original-typography fidelity.'), indent=2)+'\n', encoding='utf-8')

def run(job):
    stem = job['font'] + '-' + job['route']
    output = OUT / (stem + '.png')
    cmd = [str(EXE), '-platform', 'offscreen', '-no-gui', '-allow-multiple-instances', '-config',
           str(OUT / (stem + '-settings')), '-autostart', 'scripts/Pro/Tools/Dwg2Bmp/Dwg2Bmp.js',
           '-o', str(output), '-x', '3200', '-y', '2200', '-window=' + window, '-b', 'white', '-n']
    if job['font'] == 'Arial-substitution':
        cmd += ['-fs', 'txt', 'Arial']
    cmd.append(job['input'])
    before = sha(job['input'])
    proc = subprocess.run(cmd, cwd=EXE.parent, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          timeout=120, creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / (stem + '.log')).write_bytes(proc.stdout)
    result = dict(job, command=cmd, exit=proc.returncode, input_sha256=before,
                  input_unchanged=sha(job['input']) == before, image_sha256=sha(output) if output.exists() else None)
    print(stem, result['exit'], bool(result['image_sha256']), flush=True)
    return result

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(run, jobs))
(OUT / 'pilot-receipts.json').write_text(json.dumps(dict(results=results), indent=2)+'\n', encoding='utf-8')
assert all(r['exit'] == 0 and r['input_unchanged'] and r['image_sha256'] for r in results)
