# CAD receiving review

Strict comparison: **differences**; 1 differences outside allowed edits.

Acceptance has not been performed. This packet explains differences; it does not approve a returned drawing.

Before SHA-256: c64f5ac8f53f7f35ed0f119abdc28c1e11eb5c7cc28011ddaf079940cfee2b7d
After SHA-256: 15d8198619ee233c82b01b70dd098bc134183b3764b8553e8ea1cbee3c38529f

DXF version: AC1015 to AC1015.
Declared save metadata changed: True. These named exclusions are retained in the strict comparison.

## Asset attribute values

| Position / field | Before | Returned | Observation |
|---|---|---|---|
| S1/P1/PAST1/FDV-2210 / ICT_ID | S1/P1/PAST1/FDV-2210 | S1/P1/PAST1/FDV-2210 | unchanged |
| S1/P1/PAST1/FDV-2210 / MODEL | SRC-2 | MANUAL-OTHER | planned edit missing or different |
| S1/P1/PAST1/FDV-2210 / SERIAL | UNKNOWN | AV-88412 | planned edit observed |
| S1/P1/PAST1/FDV-2210 / SIZE | DN50 | DN65 | planned edit observed |
| S1/P1/PAST1/FDV-2210 / TAG | FDV-2210 | FDV-2210 | unchanged |
| S1/P1/PAST1/FDV-2210 / VENDOR_NOTE | retain this unfamiliar attribute | retain this unfamiliar attribute | unchanged |

## Identity and block changes

| Position | Observation | Before | Returned |
|---|---|---|---|

## Layouts

| Record | Before | Returned |
|---|---|---|

## Block definitions

| Record | Before | Returned |
|---|---|---|

## Named layers, styles and tables

0 records; see review.json and strict-comparison.json for every exact change.

## Header values

0 records; see review.json and strict-comparison.json for every exact change.

## Drawing records to inspect

| Handle / type | Scope before / returned | Observation | Fields |
|---|---|---|---|

## All drawing record field values

0 records; see review.json and strict-comparison.json for every exact change.

## Strict entity queue summary

| Observation at handle | Count |
|---|---|
| same type changed | 1 |

## Every strict entity difference remains open

1 records; see review.json and strict-comparison.json for every exact change.

## Boundaries and next step

Diagnostic only; the original strict comparison and its exit status remain authoritative for this software gate. Handles are not matched by geometry. Added/removed handles may be remapping, not added/removed physical objects. Drawing fields are explicit ezdxf attributes of direct block/layout records, not geometry or visual equivalence. Child ATTRIB/complex payloads, XDATA and other objects remain in the strict queue. Named table fields do not cover complete linetype patterns or style behavior. No difference is automatically waived, accepted or called harmless.

Qualify the intended receiver/settings, inspect appearance and editable data, investigate every remaining difference, then retain an owner-reviewed receiving checklist. No context update is promoted by this report.

Files: [review data](review.json), [strict comparison](strict-comparison.json), [original drawing](originals/before.dxf), [returned drawing](originals/after.dxf) and [receipt](receipt.json).
