import concurrent.futures,hashlib,json,os,subprocess
from pathlib import Path
root=Path.cwd();out=root/'data/external/cad-qualification/render-font-4';out.mkdir()
exe=Path(r'C:\Users\Steve\.cp-scratch\qcad-3.33.1-qt5-native-test\application\qcad-3.33.1-trial-win64\qcadcmd.com')
plan=json.loads((root/'data/external/cad-qualification/render-diagnostic-3/pilot-plan.json').read_bytes())
jobs=[j for j in plan['jobs'] if j['font']=='Arial-substitution']
for j in jobs:j['font']='native Standard -> Arial (actual probed name)'
(out/'plan.json').write_text(json.dumps(dict(jobs=jobs,reason='First txt->Arial attempt had zero pixel effect. Native probe identifies Standard; all source bytes and previous attempts retained.'),indent=2)+'\n',encoding='utf-8')
def run(j):
 output=out/(j['route']+'.png');before=hashlib.sha256(Path(j['input']).read_bytes()).hexdigest()
 cmd=[str(exe),'-platform','offscreen','-no-gui','-allow-multiple-instances','-config',str(out/(j['route']+'-settings')),'-autostart','scripts/Pro/Tools/Dwg2Bmp/Dwg2Bmp.js','-o',str(output),'-x','3200','-y','2200','-window='+j['window'],'-b','white','-n','-fs','Standard','Arial',j['input']]
 p=subprocess.run(cmd,cwd=exe.parent,env=dict(os.environ,QT_QPA_FONTDIR=r'C:\Windows\Fonts'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
 (out/(j['route']+'.log')).write_bytes(p.stdout)
 return dict(j,command=cmd,exit=p.returncode,input_sha256=before,input_unchanged=hashlib.sha256(Path(j['input']).read_bytes()).hexdigest()==before,image_sha256=hashlib.sha256(output.read_bytes()).hexdigest() if output.exists() else None)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,jobs))
(out/'receipt.json').write_text(json.dumps(dict(results=results,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),font_sha256=hashlib.sha256(Path(r'C:\Windows\Fonts\arial.ttf').read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
print(json.dumps([{k:v for k,v in r.items() if k not in ('command','input')} for r in results],indent=2))
assert all(r['exit']==0 and r['image_sha256'] and r['input_unchanged'] for r in results)
