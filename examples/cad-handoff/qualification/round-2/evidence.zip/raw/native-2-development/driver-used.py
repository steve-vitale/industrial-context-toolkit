import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd()
Q = ROOT / 'examples/cad-handoff/qualification'
OUT = ROOT / 'data/external/cad-qualification/native-2-development'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT / 'scripts'))
import cad_handoff as ch

helper = Q / 'native-batch.js'
exe = Path(r'C:\Users\Steve\.cp-scratch\qcad-3.33.1-qt5-native-test\application\qcad-3.33.1-trial-win64\qcadcmd.com')
cases = json.loads((Q / 'round-1/native-1/manifest.json').read_bytes())['cases']
for c in cases:
    if c['id'] != 'original-valve':
        c['candidate'] = str(ROOT / 'data/external/cad-qualification/regression-2' / c['id'] / 'candidate/candidate.dxf')
    for r, suffix in [('native_default', 'default'), ('native_r15', 'r15')]:
        c[r] = str(OUT / (c['id'] + '-' + suffix + '.dxf'))
cases.append(dict(id='reserve-r12', source=str(Q / 'fixtures/reserve-r12.dxf'),
                  plan=str(Q / 'fixtures/reserve-r12.plan.json'),
                  candidate=str(ROOT / 'data/external/cad-qualification/regression-2/reserve-r12/candidate/candidate.dxf'),
                  native_default=str(OUT / 'reserve-r12-default.dxf'), native_r15=str(OUT / 'reserve-r12-r15.dxf')))
for c in cases:
    for k in ['source', 'plan', 'candidate']:
        assert Path(c[k]).is_file(), (c['id'], k)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def native(manifest, label):
    path = OUT / (label + '-manifest.json')
    path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    command = [str(exe), '-platform', 'offscreen', '-no-gui', '-allow-multiple-instances',
               '-config', str(OUT / (label + '-settings')), '-autostart', str(helper), '-m', str(path)]
    proc = subprocess.run(command, cwd=exe.parent, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          timeout=100, creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / (label + '-log.txt')).write_bytes(proc.stdout)
    readbacks = [json.loads(line.split('ICT_QUAL_NATIVE ', 1)[1]) for line in proc.stdout.decode('utf-8', errors='replace').splitlines()
                 if line.startswith('ICT_QUAL_NATIVE ')]
    receipt = dict(command=command, process_exit=proc.returncode, helper_sha256=sha(helper),
                   executable_sha256=sha(exe), expected=len(manifest['cases']), returned=len(readbacks),
                   readbacks=readbacks, scope='exposed development; native engine only, not GUI or engineering acceptance')
    (OUT / (label + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    assert proc.returncode == 0 and len(readbacks) == len(manifest['cases'])
    return readbacks

def by_identity(rows):
    result = {}
    for row in rows:
        values = row['attributes'];identity = values['ICT_ID']
        assert identity not in result
        result[identity] = values
    return result

readbacks = native(dict(cases=cases), 'edited')
summary = []
for c, r in zip(cases, readbacks):
    assert c['id'] == r['id']
    item = dict(id=c['id'], errors={k: v for k, v in r.items() if k.endswith('error')}, routes={})
    try:
        plan = json.loads(Path(c['plan']).read_bytes())
        expected = by_identity(r['source'])
        for change in plan['changes']:
            assert expected[change['id']][change['attribute']] == change['before']
            expected[change['id']][change['attribute']] = change['after']
        for route in ['candidate', 'native_default', 'native_r15']:
            if route not in r:
                item['routes'][route] = dict(error='Native route did not return rows')
                continue
            comparison = ch.compare(ch.snapshot(Path(c['source'])), ch.snapshot(Path(c[route])), plan)
            item['routes'][route] = dict(all_stored_attributes_match=by_identity(r[route]) == expected,
                                        strict_status=comparison['status'], strict_differences=len(comparison['differences']),
                                        sha256=sha(c[route]))
            (OUT / (c['id'] + '-' + route + '-comparison.json')).write_text(json.dumps(comparison, indent=2) + '\n', encoding='utf-8')
    except Exception as error:
        item['error'] = f'{type(error).__name__}: {error}'
    summary.append(item)
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2), flush=True)

# A separate QCAD process must reopen the candidate after the editing process has exited.
readback2 = native(dict(read_only=True, cases=cases), 'fresh-process')
for c, r in zip(cases, readback2):
    assert c['id'] == r['id'] and 'error' not in r
    expected = by_identity(r['source'])
    for change in json.loads(Path(c['plan']).read_bytes())['changes']:
        expected[change['id']][change['attribute']] = change['after']
    assert by_identity(r['candidate']) == expected
print('Fresh-process candidate readback:', len(readback2), 'cases; no GUI acceptance')

old_ast = ast.parse((Q / 'history/method-1/scripts/cad_handoff.py').read_text(encoding='utf-8'))
new_ast = ast.parse((ROOT / 'scripts/cad_handoff.py').read_text(encoding='utf-8'))
get_compare = lambda tree: next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'compare')
assert ast.dump(get_compare(old_ast)) == ast.dump(get_compare(new_ast))
old = json.loads((Q / 'round-1/native-1/manifest.json').read_bytes())['cases'][0]
plan = json.loads(Path(old['plan']).read_bytes())
counts = []
for route in ['native_default', 'native_r15']:
    comparison = ch.compare(ch.snapshot(Path(old['source'])), ch.snapshot(Path(old[route])), plan)
    counts.append(len(comparison['differences']))
assert counts == [335, 344], counts
print('Comparator AST unchanged; exact original native returns still report', counts)
