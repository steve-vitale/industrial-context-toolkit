"""Same-settings native source/candidate renders; no edits to drawings or rendered pixels."""
import concurrent.futures
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd()
OUT = ROOT / 'data/external/cad-qualification/render-validation-2'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT / 'scripts'))
import cad_handoff as ch
from ezdxf import bbox
from PIL import Image

exe = Path(r'C:\Users\Steve\.cp-scratch\qcad-3.33.1-qt5-native-test\application\qcad-3.33.1-trial-win64\qcadcmd.com')
cases = json.loads((ROOT / 'data/external/cad-qualification/native-validation-2/edited-manifest.json').read_bytes())['cases']
jobs = []

def window_for(entities):
    box = bbox.extents(entities, fast=True)
    if not box.has_data:
        raise ValueError('Cannot invent an empty view window')
    x0, y0 = box.extmin.x, box.extmin.y
    w, h = max(box.size.x, 10), max(box.size.y, 10)
    pad = max(w, h) * .08
    values = (x0 - pad, y0 - pad, w + 2 * pad, h + 2 * pad)
    assert all(math.isfinite(v) for v in values)
    return ','.join(f'{v:.8f}' for v in values)

for c in cases:
    source, candidate = ch.load(c['source']), ch.load(c['candidate'])
    views = []
    entities = []
    for doc in (source, candidate):
        entities.extend(doc.modelspace())
        for ref in doc.modelspace().query('INSERT'):
            entities.extend(ref.attribs)
    views.append(('model-full', None, window_for(entities)))
    # Same declared first stable asset, all of its attached labels; not outcome-selected.
    first = ch.assets(source)[0]['id']
    detail = []
    for doc in (source, candidate):
        for ref in doc.modelspace().query('INSERT'):
            if ref.get_attrib_text('ICT_ID') == first:
                detail.extend(ref.attribs)
    views.append(('first-asset-labels', None, window_for(detail)))
    for layout in source.layouts:
        if layout.name == 'Model' or not len(layout):
            continue
        other = candidate.layouts.get(layout.name)
        views.append(('paper-' + str(len(views)), layout.name, window_for(list(layout) + list(other))))
    for view, block, window in views:
        for route in ('source', 'candidate'):
            jobs.append(dict(case=c['id'], view=view, route=route, input=c[route], block=block,
                             window=window, width=3200, height=2200, background='white', color_correction=True))
(OUT / 'render-plan.json').write_text(json.dumps(dict(scope='Native rendering only; trial watermark retained. Extents are passive ezdxf estimates; actual readable/visual review still required.',jobs=jobs),indent=2)+'\n',encoding='utf-8')

def run(job):
    stem = job['case'] + '-' + job['view'] + '-' + job['route']
    output = OUT / (stem + '.png')
    command = [str(exe), '-platform', 'offscreen', '-no-gui', '-allow-multiple-instances',
               '-config', str(OUT / (stem + '-settings')), '-autostart', 'scripts/Pro/Tools/Dwg2Bmp/Dwg2Bmp.js',
               '-o', str(output), '-x', str(job['width']), '-y', str(job['height']),
               '-window=' + job['window'], '-b', 'white', '-c']
    if job['block']:
        command.append('-block=' + job['block'])
    command.append(job['input'])
    result = dict(job, command=command)
    try:
        proc = subprocess.run(command, cwd=exe.parent, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              timeout=120, creationflags=subprocess.CREATE_NO_WINDOW)
        (OUT / (stem + '.log')).write_bytes(proc.stdout)
        result['exit'] = proc.returncode
        if output.exists():
            with Image.open(output) as img:
                result['image_size'] = list(img.size)
            result['image_sha256'] = hashlib.sha256(output.read_bytes()).hexdigest()
        else:
            result['error'] = 'No native PNG emitted'
    except Exception as error:
        result['error'] = f'{type(error).__name__}: {error}'
    print(stem, result.get('exit'), result.get('image_size', result.get('error')), flush=True)
    return result

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(run, jobs))
(OUT / 'receipts.json').write_text(json.dumps(dict(driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),results=results),indent=2)+'\n',encoding='utf-8')
raise SystemExit(int(any(r.get('error') or r.get('exit') != 0 or r.get('image_size') != [3200,2200] for r in results)))
