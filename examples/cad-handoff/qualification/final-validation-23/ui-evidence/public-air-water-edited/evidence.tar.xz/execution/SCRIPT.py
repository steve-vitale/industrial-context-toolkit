import hashlib,json,subprocess,sys
from pathlib import Path
b=Path(r"C:\Users\Steve\.cp-scratch\cad-full-ui-22");case=sys.argv[1]
if case not in ("public-air-water","final-foreign"):raise ValueError("Predetermined UI cases only")
w=b/"worktree";driver=w/"examples/cad-handoff/qualification/full-ui-22/run_wait.py"
config=Path(r"C:\Users\Steve\.cp-scratch\cad-native-ui-pairs-19\jobs-5\libre-air-water-receiving\.configuration\QCAD3.conf")
for role in ("baseline","edited"):
 label="final23-"+case+"-"+role+"-1";host=b/(label+"-host");host.mkdir()
 cmd=[sys.executable,str(driver),str(b/"final-native-preparation-1/ui"/case),role,str(config),str(b/label),"--name","ict-cad-"+label]
 (host/"COMMAND.json").write_text(json.dumps(cmd,indent=2)+"\n",encoding="utf-8",newline="\n")
 (host/"SCRIPT.py").write_bytes(Path(__file__).read_bytes())
 with (host/"stdout.txt").open("wb") as out,(host/"stderr.txt").open("wb") as err:r=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
 (host/"EXIT.json").write_text(json.dumps(dict(exit=r.returncode))+"\n",encoding="utf-8",newline="\n")
 print("Original final UI exit",case,role,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
