# CAD receiving review

Strict comparison: **differences**; 2 differences outside allowed edits.

Acceptance has not been performed. This packet explains differences; it does not approve a returned drawing.

Before SHA-256: e326270bb69efc00198b6090ae04744c179cea013b8ef6bb0bc166907158ac9e
After SHA-256: e1e98f97e2988898a0e2a7712385784e31f0deb4bee1b6640a62b9f3c071c655

DXF version: AC1021 to AC1021.
Declared save metadata changed: False. These named exclusions are retained in the strict comparison.

## Asset attribute values

| Position / field | Before | Returned | Observation |
|---|---|---|---|
| AUTHORED-QUAL/public-air-water/1 / ICT_ID | AUTHORED-QUAL/public-air-water/1 | AUTHORED-QUAL/public-air-water/1 | unchanged |
| AUTHORED-QUAL/public-air-water/1 / MANUFACTURER | QUAL-BEFORE | OTHER-CHOICE | planned edit missing or different |
| AUTHORED-QUAL/public-air-water/1 / TAG | QA-1 | FIELD-OBSERVED | unexpected |

## Identity and block changes

| Position | Observation | Before | Returned |
|---|---|---|---|

## Layouts

| Record | Before | Returned |
|---|---|---|

## Block definitions

| Record | Before | Returned |
|---|---|---|

## Named layers, styles and tables

0 records; see review.json and strict-comparison.json for every exact change.

## Header values

0 records; see review.json and strict-comparison.json for every exact change.

## Drawing records to inspect

| Handle / type | Scope before / returned | Observation | Fields |
|---|---|---|---|

## All drawing record field values

0 records; see review.json and strict-comparison.json for every exact change.

## Strict entity queue summary

| Observation at handle | Count |
|---|---|
| same type changed | 2 |

## Every strict entity difference remains open

2 records; see review.json and strict-comparison.json for every exact change.

## Boundaries and next step

Diagnostic only; the original strict comparison and its exit status remain authoritative for this software gate. Handles are not matched by geometry. Added/removed handles may be remapping, not added/removed physical objects. Drawing fields are explicit ezdxf attributes of direct block/layout records, not geometry or visual equivalence. Child ATTRIB/complex payloads, XDATA and other objects remain in the strict queue. Named table fields do not cover complete linetype patterns or style behavior. No difference is automatically waived, accepted or called harmless.

Qualify the intended receiver/settings, inspect appearance and editable data, investigate every remaining difference, then retain an owner-reviewed receiving checklist. No context update is promoted by this report.

Files: [review data](review.json), [strict comparison](strict-comparison.json), [original drawing](originals/before.dxf), [returned drawing](originals/after.dxf) and [receipt](receipt.json).
