# CAD receiving review

Strict comparison: **differences**; 1 differences outside allowed edits.

Acceptance has not been performed. This packet explains differences; it does not approve a returned drawing.

Before SHA-256: ac645ecb3e34aae96becbbb6c14a2a021981097b2dcd16cb5161d5c0a3f04d66
After SHA-256: 1d04518a17260310d6bc06ccb1e8fc327426081e1ba6a404dfa5e7bfc0acf06c

DXF version: AC1027 to AC1027.
Declared save metadata changed: False. These named exclusions are retained in the strict comparison.

## Asset attribute values

| Position / field | Before | Returned | Observation |
|---|---|---|---|
| AUTHORED-QUAL/public-hatch/1 / ICT_ID | AUTHORED-QUAL/public-hatch/1 | AUTHORED-QUAL/public-hatch/1 | unchanged |
| AUTHORED-QUAL/public-hatch/1 / MANUFACTURER | QUAL-BEFORE | QUAL-AFTER | planned edit observed |
| AUTHORED-QUAL/public-hatch/1 / TAG | QA-1 | QA-1 | unchanged |
| AUTHORED-QUAL/public-hatch/2 / ICT_ID | AUTHORED-QUAL/public-hatch/2 | AUTHORED-QUAL/public-hatch/2 | unchanged |
| AUTHORED-QUAL/public-hatch/2 / MANUFACTURER | QUAL-BEFORE | QUAL-AFTER | planned edit observed |
| AUTHORED-QUAL/public-hatch/2 / TAG | QA-2 | FIELD-OBSERVED | unexpected |

## Identity and block changes

| Position | Observation | Before | Returned |
|---|---|---|---|

## Layouts

| Record | Before | Returned |
|---|---|---|

## Block definitions

| Record | Before | Returned |
|---|---|---|

## Named layers, styles and tables

0 records; see review.json and strict-comparison.json for every exact change.

## Header values

0 records; see review.json and strict-comparison.json for every exact change.

## Drawing records to inspect

| Handle / type | Scope before / returned | Observation | Fields |
|---|---|---|---|

## All drawing record field values

0 records; see review.json and strict-comparison.json for every exact change.

## Strict entity queue summary

| Observation at handle | Count |
|---|---|
| same type changed | 1 |

## Every strict entity difference remains open

1 records; see review.json and strict-comparison.json for every exact change.

## Boundaries and next step

Diagnostic only; the original strict comparison and its exit status remain authoritative for this software gate. Handles are not matched by geometry. Added/removed handles may be remapping, not added/removed physical objects. Drawing fields are explicit ezdxf attributes of direct block/layout records, not geometry or visual equivalence. Child ATTRIB/complex payloads, XDATA and other objects remain in the strict queue. Named table fields do not cover complete linetype patterns or style behavior. No difference is automatically waived, accepted or called harmless.

Qualify the intended receiver/settings, inspect appearance and editable data, investigate every remaining difference, then retain an owner-reviewed receiving checklist. No context update is promoted by this report.

Files: [review data](review.json), [strict comparison](strict-comparison.json), [original drawing](originals/before.dxf), [returned drawing](originals/after.dxf) and [receipt](receipt.json).
