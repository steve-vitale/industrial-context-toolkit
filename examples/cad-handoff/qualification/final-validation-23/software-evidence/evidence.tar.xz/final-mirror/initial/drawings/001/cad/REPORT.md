# CAD receiving review

Strict comparison: **differences**; 2 differences outside allowed edits.

Acceptance has not been performed. This packet explains differences; it does not approve a returned drawing.

Before SHA-256: 47c935a630113c4736a2a5f1a5bb35e8948bb83978a6ddbe2a8163ba392f1165
After SHA-256: 334f7fb7406d596d29917576f01154f4b93aa2b58969af35fb8de551477b5aba

DXF version: AC1015 to AC1015.
Declared save metadata changed: True. These named exclusions are retained in the strict comparison.

## Asset attribute values

| Position / field | Before | Returned | Observation |
|---|---|---|---|
| final-mirror/asset-1 / ICT_ID | final-mirror/asset-1 | final-mirror/asset-1 | unchanged |
| final-mirror/asset-1 / MODEL | Étage-7 | OTHER-CHOICE | planned edit missing or different |
| final-mirror/asset-1 / SERIAL | UNCHANGED-0 | UNCHANGED-0 | unchanged |
| final-mirror/asset-1 / SIZE | DN50 | DN50 | unchanged |
| final-mirror/asset-1 / TAG | FV-101 | FV-101 | unchanged |
| final-mirror/asset-1 / VENDOR_PRIVATE | retain {vendor} \P 0 | retain {vendor} \P 0 | unchanged |
| final-mirror/asset-2 / ICT_ID | final-mirror/asset-2 | final-mirror/asset-2 | unchanged |
| final-mirror/asset-2 / MODEL | Étage-7 | Étage-8 | planned edit observed |
| final-mirror/asset-2 / SERIAL | UNCHANGED-1 | FIELD-OBSERVED | unexpected |
| final-mirror/asset-2 / SIZE | DN50 | DN50 | unchanged |
| final-mirror/asset-2 / TAG | FV-102 | FV-102 | unchanged |
| final-mirror/asset-2 / VENDOR_PRIVATE | retain {vendor} \P 1 | retain {vendor} \P 1 | unchanged |

## Identity and block changes

| Position | Observation | Before | Returned |
|---|---|---|---|

## Layouts

| Record | Before | Returned |
|---|---|---|

## Block definitions

| Record | Before | Returned |
|---|---|---|

## Named layers, styles and tables

0 records; see review.json and strict-comparison.json for every exact change.

## Header values

0 records; see review.json and strict-comparison.json for every exact change.

## Drawing records to inspect

| Handle / type | Scope before / returned | Observation | Fields |
|---|---|---|---|

## All drawing record field values

0 records; see review.json and strict-comparison.json for every exact change.

## Strict entity queue summary

| Observation at handle | Count |
|---|---|
| same type changed | 2 |

## Every strict entity difference remains open

2 records; see review.json and strict-comparison.json for every exact change.

## Boundaries and next step

Diagnostic only; the original strict comparison and its exit status remain authoritative for this software gate. Handles are not matched by geometry. Added/removed handles may be remapping, not added/removed physical objects. Drawing fields are explicit ezdxf attributes of direct block/layout records, not geometry or visual equivalence. Child ATTRIB/complex payloads, XDATA and other objects remain in the strict queue. Named table fields do not cover complete linetype patterns or style behavior. No difference is automatically waived, accepted or called harmless.

Qualify the intended receiver/settings, inspect appearance and editable data, investigate every remaining difference, then retain an owner-reviewed receiving checklist. No context update is promoted by this report.

Files: [review data](review.json), [strict comparison](strict-comparison.json), [original drawing](originals/before.dxf), [returned drawing](originals/after.dxf) and [receipt](receipt.json).
