# CAD receiving review

Strict comparison: **differences**; 2 differences outside allowed edits.

Acceptance has not been performed. This packet explains differences; it does not approve a returned drawing.

Before SHA-256: 1106d71d1fc86456efd28607d4f23c5ba11ffebfac8f0a7b38d3c511bb34dfe8
After SHA-256: 9c77b313c66ab8c5ece7d1a8a8ef13f3af4cf4dfa6922bdb57dbb9d14a1f18b6

DXF version: AC1032 to AC1032.
Declared save metadata changed: True. These named exclusions are retained in the strict comparison.

## Asset attribute values

| Position / field | Before | Returned | Observation |
|---|---|---|---|
| final-foreign/asset-1 / ICT_ID | final-foreign/asset-1 | final-foreign/asset-1 | unchanged |
| final-foreign/asset-1 / MODEL | Unit-17 | OTHER-CHOICE | planned edit missing or different |
| final-foreign/asset-1 / SERIAL | UNCHANGED-0 | UNCHANGED-0 | unchanged |
| final-foreign/asset-1 / SIZE | DN50 | DN50 | unchanged |
| final-foreign/asset-1 / TAG | FV-101 | FV-101 | unchanged |
| final-foreign/asset-1 / VENDOR_PRIVATE | retain {vendor} \P 0 | retain {vendor} \P 0 | unchanged |
| final-foreign/asset-2 / ICT_ID | final-foreign/asset-2 | final-foreign/asset-2 | unchanged |
| final-foreign/asset-2 / MODEL | Unit-17 | Unit-18 | planned edit observed |
| final-foreign/asset-2 / SERIAL | UNCHANGED-1 | FIELD-OBSERVED | unexpected |
| final-foreign/asset-2 / SIZE | DN50 | DN50 | unchanged |
| final-foreign/asset-2 / TAG | FV-102 | FV-102 | unchanged |
| final-foreign/asset-2 / VENDOR_PRIVATE | retain {vendor} \P 1 | retain {vendor} \P 1 | unchanged |
| final-foreign/asset-3 / ICT_ID | final-foreign/asset-3 | final-foreign/asset-3 | unchanged |
| final-foreign/asset-3 / MODEL | Unit-17 | Unit-18 | planned edit observed |
| final-foreign/asset-3 / SERIAL | UNCHANGED-2 | UNCHANGED-2 | unchanged |
| final-foreign/asset-3 / SIZE | DN50 | DN50 | unchanged |
| final-foreign/asset-3 / TAG | FV-103 | FV-103 | unchanged |
| final-foreign/asset-3 / VENDOR_PRIVATE | retain {vendor} \P 2 | retain {vendor} \P 2 | unchanged |

## Identity and block changes

| Position | Observation | Before | Returned |
|---|---|---|---|

## Layouts

| Record | Before | Returned |
|---|---|---|

## Block definitions

| Record | Before | Returned |
|---|---|---|

## Named layers, styles and tables

0 records; see review.json and strict-comparison.json for every exact change.

## Header values

0 records; see review.json and strict-comparison.json for every exact change.

## Drawing records to inspect

| Handle / type | Scope before / returned | Observation | Fields |
|---|---|---|---|

## All drawing record field values

0 records; see review.json and strict-comparison.json for every exact change.

## Strict entity queue summary

| Observation at handle | Count |
|---|---|
| same type changed | 2 |

## Every strict entity difference remains open

2 records; see review.json and strict-comparison.json for every exact change.

## Boundaries and next step

Diagnostic only; the original strict comparison and its exit status remain authoritative for this software gate. Handles are not matched by geometry. Added/removed handles may be remapping, not added/removed physical objects. Drawing fields are explicit ezdxf attributes of direct block/layout records, not geometry or visual equivalence. Child ATTRIB/complex payloads, XDATA and other objects remain in the strict queue. Named table fields do not cover complete linetype patterns or style behavior. No difference is automatically waived, accepted or called harmless.

Qualify the intended receiver/settings, inspect appearance and editable data, investigate every remaining difference, then retain an owner-reviewed receiving checklist. No context update is promoted by this report.

Files: [review data](review.json), [strict comparison](strict-comparison.json), [original drawing](originals/before.dxf), [returned drawing](originals/after.dxf) and [receipt](receipt.json).
