# CAD receiving review

Strict comparison: **differences**; 1 differences outside allowed edits.

Acceptance has not been performed. This packet explains differences; it does not approve a returned drawing.

Before SHA-256: 2ddbbf484c5602c93bb47640e1164e71b047f77463369cb05c383f1bce894b6f
After SHA-256: 49e88509dbdf58c8d02209bf3e4e36478e2a95e1c12ca72a4dabe0c06516f61a

DXF version: AC1021 to AC1021.
Declared save metadata changed: False. These named exclusions are retained in the strict comparison.

## Asset attribute values

| Position / field | Before | Returned | Observation |
|---|---|---|---|
| AUTHORED-QUAL/public-power/1 / ICT_ID | AUTHORED-QUAL/public-power/1 | AUTHORED-QUAL/public-power/1 | unchanged |
| AUTHORED-QUAL/public-power/1 / MANUFACTURER | QUAL-BEFORE | QUAL-AFTER | planned edit observed |
| AUTHORED-QUAL/public-power/1 / TAG | QA-1 | FIELD-OBSERVED | unexpected |

## Identity and block changes

| Position | Observation | Before | Returned |
|---|---|---|---|

## Layouts

| Record | Before | Returned |
|---|---|---|

## Block definitions

| Record | Before | Returned |
|---|---|---|

## Named layers, styles and tables

0 records; see review.json and strict-comparison.json for every exact change.

## Header values

0 records; see review.json and strict-comparison.json for every exact change.

## Drawing records to inspect

| Handle / type | Scope before / returned | Observation | Fields |
|---|---|---|---|

## All drawing record field values

0 records; see review.json and strict-comparison.json for every exact change.

## Strict entity queue summary

| Observation at handle | Count |
|---|---|
| same type changed | 1 |

## Every strict entity difference remains open

1 records; see review.json and strict-comparison.json for every exact change.

## Boundaries and next step

Diagnostic only; the original strict comparison and its exit status remain authoritative for this software gate. Handles are not matched by geometry. Added/removed handles may be remapping, not added/removed physical objects. Drawing fields are explicit ezdxf attributes of direct block/layout records, not geometry or visual equivalence. Child ATTRIB/complex payloads, XDATA and other objects remain in the strict queue. Named table fields do not cover complete linetype patterns or style behavior. No difference is automatically waived, accepted or called harmless.

Qualify the intended receiver/settings, inspect appearance and editable data, investigate every remaining difference, then retain an owner-reviewed receiving checklist. No context update is promoted by this report.

Files: [review data](review.json), [strict comparison](strict-comparison.json), [original drawing](originals/before.dxf), [returned drawing](originals/after.dxf) and [receipt](receipt.json).
