import json,subprocess,sys
from pathlib import Path
b=Path(r"C:\Users\Steve\.cp-scratch\cad-full-ui-22")
for role,driver in (("api","run_native.py"),("render","render.py")):
 job=b/"final-native-preparation-1"/role;host=b/("final23-"+role+"-1-host");host.mkdir();name="ict-cad-final23-"+role+"-1"
 def write(n,v):(host/n).write_text(json.dumps(v,indent=2)+"\n",encoding="utf-8",newline="\n")
 (host/"SCRIPT.py").write_bytes(Path(__file__).read_bytes())
 cmd=["docker","create","--name",name,"--network","none","--user","1001:1001","--memory","2g","--cpus","1","--pids-limit","256","--cap-drop","ALL","--security-opt","no-new-privileges","--mount","type=bind,source="+job.as_posix()+",target=/work","--entrypoint","python3","sha256:bb4390214744897de88b2198f0cbf812aec4be42923311298e7a5e3a5646bef8","/work/"+driver]
 write("COMMAND.json",cmd);r=subprocess.run(cmd,capture_output=True,text=True);write("CREATE.json",dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr));r.check_returncode()
 write("BEFORE.json",json.loads(subprocess.check_output(["docker","inspect",name])))
 print("Final native container created",role,r.stdout.strip(),flush=True)
 with (host/"stdout.txt").open("wb") as out,(host/"stderr.txt").open("wb") as err:r=subprocess.run(["docker","start","-a",name],stdout=out,stderr=err)
 write("EXIT.json",dict(exit=r.returncode));write("AFTER.json",json.loads(subprocess.check_output(["docker","inspect",name])))
 print("Original final native exit",role,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
