import json,subprocess,sys,hashlib
from pathlib import Path
b=Path(r'C:\Users\Steve\.cp-scratch\cad-full-ui-22');case=sys.argv[1];role=sys.argv[2]
if case not in ('cp1251','braces') or role not in ('baseline','edited','receiving'):raise ValueError('Declared second revision cases/roles only')
label=case+'-second-'+role+'-1';host=b/(label+'-host');host.mkdir();r=b/'worktree/examples/cad-handoff/qualification/full-ui-22'
launch=json.loads((r/'SECOND-REVISION-LAUNCH-1.json').read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
lf=lambda p:hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
if lf(r/'SECOND-REVISION-PREPARATION-1.json')!=launch['preparation_sha256_lf'] or sha(Path(__file__))!=launch['host_wrapper_sha256']:raise ValueError('Declared preparation/host differs')
cmd=[sys.executable,str(r/'run_wait.py'),str(b/('second-revision-preparation-1/cases/validation-'+case)),role,r'C:\Users\Steve\.cp-scratch\cad-native-ui-pairs-19\jobs-5\libre-air-water-receiving\.configuration\QCAD3.conf',str(b/label),'--name','ict-cad-full22-'+label]
if role=='receiving':cmd+=['--returns',str(b/'second-native-matched-1')]
(host/'COMMAND.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8',newline='\n')
(host/'SCRIPT.py').write_bytes(Path(__file__).read_bytes())
(host/'FREEZE.json').write_text(json.dumps(dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=b/'worktree',text=True).strip(),script_sha256=sha(Path(__file__)),launch_sha256=sha(r/'SECOND-REVISION-LAUNCH-1.json')),indent=2)+'\n',encoding='utf-8',newline='\n')
with (host/'stdout.txt').open('wb') as out,(host/'stderr.txt').open('wb') as err:result=subprocess.run(cmd,stdout=out,stderr=err)
(host/'EXIT.json').write_text(json.dumps(dict(exit=result.returncode))+'\n',encoding='utf-8',newline='\n')
print('Original native second revision host exit',case,role,result.returncode);sys.exit(result.returncode)
