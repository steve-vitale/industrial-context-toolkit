// Public native object/version observations and no-operation exports. No UI qualification.
include('scripts/simple.js');
include('scripts/Tools/arguments.js');
function readJson(path){var f=new QFile(path);if(!f.open(QIODevice.ReadOnly))throw new Error('Cannot read '+path);var s=new QTextStream(f).readAll();f.close();return JSON.parse(s);}
function value(v,depth){
 if(depth>8)return {type:'unsupported-depth',display:String(v)};
 if(v===null)return {type:'null',value:null};
 var kind=typeof v;
 if(kind==='undefined')return {type:'undefined'};
 if(kind==='string'||kind==='boolean')return {type:kind,value:v};
 if(kind==='number'){if(!isFinite(v))return {type:'nonfinite',display:String(v)};return {type:'number',value:v};}
 if(v instanceof Array){var a=[];for(var i=0;i<v.length;i++)a.push(value(v[i],depth+1));return {type:'array',value:a};}
 if(v instanceof RVector)return {type:'RVector',value:[value(v.x,depth+1),value(v.y,depth+1),value(v.z,depth+1)]};
 if(v instanceof RColor)return {type:'RColor',value:{index:v.getColorIndex(),custom:v.getCustomColorCode(),name:String(v.getName()),by_layer:v.isByLayer(),by_block:v.isByBlock(),valid:v.isValid()}};
 return {type:'unsupported-native-value',display:String(v)};
}
var keys=readJson('/work/KEYS.json');
function headerInventory(d){
 var known=[],dims=[],layouts=[],dv=d.queryDocumentVariablesDirect(),ds=d.queryDimStyleDirect();
 for(var i=0;i<keys.known_variables.length;i++){
  var key=keys.known_variables[i];
  if(typeof RS[key]!=='number')throw new Error('Unsupported enum '+key);
  known.push({name:key,enum_id:RS[key],present:dv.hasKnownVariable(RS[key]),value:value(d.getKnownVariable(RS[key]),0)});
 }
 for(var i=0;i<keys.dimension_variables.length;i++){
  var key=keys.dimension_variables[i].name;
  dims.push({name:key,has_override:ds.hasOverride(RS[key]),value:value(ds.getVariant(RS[key]),0)});
 }
 var ids=d.queryAllLayouts();
 for(var i=0;i<ids.length;i++){
  var layout=d.queryLayout(ids[i]),props=[];
  for(var j=0;j<keys.layout_getters.length;j++){
   var getter=keys.layout_getters[j];
   if(typeof layout[getter]!=='function')throw new Error('Unsupported layout getter '+getter);
   props.push({getter:getter,value:value(layout[getter](),0)});
  }
  layouts.push({id:String(ids[i]),properties:props});
 }
 return {known_variables:known,dimension_variables:dims,layouts:layouts};
}
function inventory(d){
 var ids=d.queryAllObjects(),objects=[],names=d.getVariables(),variables=[];
 for(var n=0;n<names.length;n++)variables.push({name:String(names[n]),value:value(d.getVariable(names[n]),0)});
 variables.sort(function(a,b){return a.name<b.name?-1:a.name>b.name?1:0;});
 for(var i=0;i<ids.length;i++){
  var o=d.queryObject(ids[i]),titles=o.getCustomPropertyTitles(),custom=[];
  for(var j=0;j<titles.length;j++){
   var keys=o.getCustomPropertyKeys(titles[j]);
   for(var k=0;k<keys.length;k++)custom.push({title:String(titles[j]),key:String(keys[k]),value:value(o.getCustomProperty(titles[j],keys[k]),0)});
  }
  var named=typeof o.getName==='function';
  objects.push({id:String(ids[i]),handle:Number(o.getHandle()).toString(16).toUpperCase(),type:Number(o.getType()),
   name_accessor:named,name:named?String(o.getName()):null,custom:custom,
   attribute:o.getType()===RS.EntityAttribute?{parent:String(o.getParentId()),tag:String(o.getTag()),
    text:String(o.getData().getText()),layer_id:String(o.getLayerId())}:null});
 }
 return {file_version:String(d.getFileVersion()),variables:variables,headers:headerInventory(d),objects:objects};
}
function chooseFilter(list,word,version){
 var found=[];
 var exact=word==='OpenDesign'?'All CAD Files [OpenDesign] (*.dxf *.dwg *.dwt *.dxb *.dgn *.dwf)':'DXF Files [dxflib] (*.dxf)';
 for(var i=0;i<list.length;i++){var s=String(list[i]);if(version?(s.indexOf('['+word+']')>=0&&s.indexOf('*.dxf')>=0&&s.indexOf(version+' [')===0):s===exact)found.push(s);}
 if(found.length!==1)throw new Error('Ambiguous/missing '+word+' '+version+' filter: '+JSON.stringify(found));
 return found[0];
}
// Appended to the unchanged header16 inventory prefix by prepare.py.
include('scripts/EAction.js');
include('scripts/File/NewFile/NewFile.js');
include('scripts/File/Print/Print.js');
function windows(){return EAction.getMdiArea().subWindowList().length;}
function events(){for(var n=0;n<5;n++)QCoreApplication.processEvents();}
function printValues(d){
 var names=['getPaperWidth','getPaperHeight','getPaperUnit','getPaperSizeMM','getPaperSizeName',
            'getPageOrientationString','getScale','getOffset'],out=[];
 for(var i=0;i<names.length;i++){
  if(typeof Print[names[i]]!=='function')throw new Error('Unsupported Print getter '+names[i]);
  var v=Print[names[i]](d);
  out.push({getter:names[i],value:names[i]==='getPaperSizeMM'?
    {type:'QSizeF',value:[value(v.width(),0),value(v.height(),0)]}:value(v,0)});
 }
 return out;
}
function execute18(job,route){
 var filter=chooseFilter(RFileImporterRegistry.getFilterStrings(),job.importer,null);
 var row={id:job.id,route:route,filter:filter,windows_before:windows()},d,di,w;
 try{
  if(route==='bare'){
   d=new RDocument(new RMemoryStorage(),new RSpatialIndexNavel());di=new RDocumentInterface(d);
   row.import_code=job.input===null?null:di.importFile(job.input,filter);
   if(job.input!==null&&row.import_code!==RDocumentInterface.IoErrorNoError)throw new Error('Native import failed');
  }else{
   w=NewFile.createMdiChild(job.input===null?undefined:job.input,filter,undefined,undefined,true);
   if(isNull(w))throw new Error('Native MDI document unavailable');
   di=w.getDocumentInterface();d=w.getDocument();
  }
  row.loaded_file=String(d.getFileName());row.windows_open=windows();
  row.has_view=!isNull(di.getLastKnownViewWithFocus());row.modified_open=d.isModified();
  row.opened=inventory(d);events();row.noop=inventory(d);
  row.print_values=printValues(d);row.after_print=inventory(d);row.modified_after_print=d.isModified();
 }catch(err){row.error=String(err);}
 finally{
  if(w){d.setModified(false);row.close_result=w.close();events();}
  else if(di)di.destroy();
  row.windows_after=windows();
 }
 return row;
}
var timer18=new QTimer(),started18=false;
timer18.timeout.connect(function(){
 if(started18)return;started18=true;timer18.stop();
 try{
  var run=readJson('/work/current.json'),jobs=readJson('/work/jobs.json').jobs;
  print('ICT_OPEN18_PROFILE '+JSON.stringify({configuration_file:String(RSettings.getFileName()),
   qt:String(RSettings.getQtVersionString()),gui:RSettings.isGuiEnabled(),route:run.route,mode:run.mode}));
  for(var i=0;i<jobs.length;i++)print('ICT_OPEN18_JOB '+JSON.stringify(execute18(jobs[i],run.route)));
  print('ICT_OPEN18_DONE '+JSON.stringify({jobs:jobs.length,route:run.route,mode:run.mode}));
 }catch(err){print('ICT_OPEN18_FATAL '+String(err));}
 // Cleanup does not save: all observed documents were explicitly discarded.
 var ws=EAction.getMdiArea().subWindowList();
 for(var j=0;j<ws.length;j++){ws[j].getDocument().setModified(false);ws[j].close();}
 QCoreApplication.quit();
});
timer18.start(250);
