# Loop/control narrative outlines

Draft for engineering review. UNKNOWN and INACTIVE remain explicit.

No supported items for this target; inspect the explicit gaps in drafts.json.

Editorial proposals (not independent evidence):

- "CF/P1/U1/P-101" / "model": "Check model" — proposed_editorial
