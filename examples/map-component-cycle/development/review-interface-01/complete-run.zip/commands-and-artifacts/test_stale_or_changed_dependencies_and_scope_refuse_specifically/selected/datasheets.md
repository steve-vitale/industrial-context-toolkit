# Datasheet scaffolds

Draft for engineering review. UNKNOWN and INACTIVE remain explicit.

## CF/P1/U2/P-101

- class (sourced_unreviewed): "pump" [EQ rev 1; CSV record 3; physical lines 3-3; column Class; supplied]
- description (sourced_unreviewed): "Other unit pump" [EQ rev 1; CSV record 3; physical lines 3-3; column Description; supplied]
- manufacturer (unknown): UNKNOWN
- model (sourced_unreviewed): "PX20" [EQ rev 1; CSV record 3; physical lines 3-3; column Model; supplied]
- serial_number (sourced_unreviewed): "OTHER-101" [EQ rev 1; CSV record 3; physical lines 3-3; column Serial; supplied]
- rated_flow (sourced_unreviewed): "35" m3/h [EQ rev 1; CSV record 3; physical lines 3-3; column RatedFlow; supplied]
- variable (unknown): UNKNOWN
- engineering_unit (unknown): UNKNOWN
- design_temperature (unknown): UNKNOWN
- range_low (unknown): UNKNOWN
- range_high (unknown): UNKNOWN
- fail_position (unknown): UNKNOWN
- operating_limits (unknown): UNKNOWN
- trip_settings (unknown): UNKNOWN

Editorial proposals (not independent evidence):

