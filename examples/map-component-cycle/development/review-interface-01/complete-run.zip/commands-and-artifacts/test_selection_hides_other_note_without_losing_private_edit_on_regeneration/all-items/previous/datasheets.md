# Datasheet scaffolds

Draft for engineering review. UNKNOWN and INACTIVE remain explicit.

## CF/P1/U1/P-101

- class (sourced_unreviewed): "pump" [EQ rev 1; CSV record 2; physical lines 2-2; column Class; supplied]
- description (sourced_unreviewed): "Feed pump" [EQ rev 1; CSV record 2; physical lines 2-2; column Description; supplied]
- manufacturer (unknown): UNKNOWN
- model (sourced_unreviewed): "PX20" [WO rev 1; CSV record 2; physical lines 2-2; column InstalledModel; supplied]; "PX20" [EQ rev 1; CSV record 2; physical lines 2-2; column Model; supplied]
- serial_number (disputed): "NEW-101" [WO rev 1; CSV record 2; physical lines 2-2; column InstalledSerial; supplied]; "OLD-101" [EQ rev 1; CSV record 2; physical lines 2-2; column Serial; supplied]
- rated_flow (disputed): "40" m3/h [EQ rev 1; CSV record 2; physical lines 2-2; column RatedFlow; supplied]; "50" m3/h [DS rev 2; CSV record 2; physical lines 2-2; column RatedFlow; supplied]
- variable (unknown): UNKNOWN
- engineering_unit (unknown): UNKNOWN
- design_temperature (sourced_unreviewed): "60" C [DS rev 2; CSV record 2; physical lines 2-2; column DesignTemperature; supplied]
- range_low (unknown): UNKNOWN
- range_high (unknown): UNKNOWN
- fail_position (unknown): UNKNOWN
- operating_limits (unknown): UNKNOWN
- trip_settings (unknown): UNKNOWN

Editorial proposals (not independent evidence):

